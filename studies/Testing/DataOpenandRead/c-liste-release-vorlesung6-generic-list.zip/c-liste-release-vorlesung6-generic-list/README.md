# Generische Liste in C (Vorlesung 6)

Motivation und Einführung in das Thema "generische Programmierung" aus Vorlesung 6.

**Anmerkung** bzgl. der CI Pipeline: Die *Test-Stage* testet hier nicht die Funktionalität des Programms, sondern lediglich, ob das Program funktioniert. Es wird lediglich *getestet*, ob überhaupt ein Program kompiliert wurde, dass ausgeführt werden kann. Im weiteren Verlauf der Vorlesung werden wir uns noch ausführlich mit den Themen CI/CD und Testen beschäftigen.